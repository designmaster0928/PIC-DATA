/*
 * GLCD128x64 interface with PIC18F4550
 * http://electronicwings.com
 * 
 */

#include <pic18f4550.h>
#include "Configuration_header_file.h"
#include "Image.h"

void GLCD_Init();
void GLCD_Command(char);
void GLCD_Char(char);
void GLCD_String(char *str);
void GLCD_Clear();
void MSdelay(unsigned int);

#define RS LATB0
#define EN LATB1
#define CS1 LATB2
#define CS2 LATB3
#define RST LATB4
#define LCD_data LATD
#define Ctrl_dir TRISB
#define Data_dir TRISD


void main() 
{
    GLCD_Init();                           /* GLCD Initialize function */
    GLCD_Clear();                          /* GLCD Display clear function */
    GLCD_String(img);  /* Print string on 0th page of GLCD */
    while(1);
}

void GLCD_Init()                      /* GLCD Initialization function */
{
    Ctrl_dir = 0;                     /* Make Control pin direction as output */
    Data_dir = 0;                     /* Make Data pin direction as output */
    OSCCON = 0x72;                    /* Internal 8MHz OSC Frequency */
    RST = 1;                          /* Make reset pin High */
	CS1 = 1; CS2 = 1;                 /* Select first Left half of display */
    MSdelay(20);
    GLCD_Command(0x3E);               /* Display OFF */
    GLCD_Command(0x40);               /* Set Y address (column=0) */
    GLCD_Command(0xB8);               /* Set x address (page=0) */
    GLCD_Command(0xC0);               /* Set z address (start line=0) */
    GLCD_Command(0x3F);               /* Display ON */
}

void GLCD_Command(char cmd)           /* GLCD Command function */
{
    LCD_data = cmd;                   /* Copy command on data pin */
    RS = 0;                           /* Make RS LOW to select command register */
    EN = 1;                           /* Make HIGH to LOW transition on Enable pin */
    NOP();
    NOP();
    EN = 0;
    NOP();
    NOP();
}

void GLCD_Char(char data)             /* GLCD Data function */
{
    LCD_data = data;                  /* Copy Data on data pin */
    RS = 1;                           /* Make RS HIGH to select data register */
    EN = 1;                           /* Make HIGH to LOW transition on Enable pin */
    NOP();
    NOP();
    EN = 0;
    NOP();
    NOP();
}

void GLCD_String(char *str)						/* GLCD string write function */
{
	int column,page,page_add=0xB8,k=0;
	float page_inc=0.5;
	CS1 = 1; CS2 = 0;							/* Select first left half of display to start print */
	for(page=0;page<16;page++)					/* Print 16 pages i.e. 8 page of each half of display */
	{
		for(column=0;column<64;column++)
			{
				GLCD_Char(str[column+k]); 		/* Print 64 column of each page */
			}
			CS1 = ~CS1; CS2 = ~CS2;
			GLCD_Command((page_add+page_inc));	/* Increment page address by 1 each after two page successful write */
			page_inc=page_inc+0.5;
			k=k+64;								/* Increment pointer by 64 after each page print */
	}
	GLCD_Command(0x40);							/* Set Y address (column=0) */
	GLCD_Command(0xB8);							/* Set x address (page=0) */
}

void GLCD_Clear()
{
	int i,j;
	CS1 = 1; CS2 = 1;									/* Select both left & right half of display */
	for(i=0;i<8;i++)
	{
		GLCD_Command((0xB8)+i);							/* Increment page each time after 64 column */
		for(j=0;j<64;j++)
		{
			GLCD_Char(0);								/* Write zeros to all 64 column */
		}
	}
	GLCD_Command(0x40);									/* Set Y address (column=0) */
	GLCD_Command(0xB8);									/* Set x address (page=0) */
}
/*********************************Delay Function********************************/
void MSdelay(unsigned int val)
{
     unsigned int i,j;
        for(i=0;i<=val;i++)
            for(j=0;j<165;j++);/*This count Provide delay of 1 ms for 8MHz Frequency */
}