/*
 * GLCD128x64 interface with PIC18F4550
 * http://electronicwings.com
 * 
 */

#include <pic18f4550.h>
#include "Configuration_header_file.h"
#include "Font_Header.h"

void GLCD_Init();
void GLCD_Command(char);
void GLCD_Char(char);
void GLCD_String(char page_no, char *str);
void GLCD_Clear();
void MSdelay(unsigned int);

#define RS LATB0
#define EN LATB1
#define CS1 LATB2
#define CS2 LATB3
#define RST LATB4
#define LCD_data LATD
#define Ctrl_dir TRISB
#define Data_dir TRISD

void main() 
{
    GLCD_Init();                           /* GLCD Initialize function */
    GLCD_Clear();                          /* GLCD Display clear function */
    GLCD_String(4,"PIC Microcontroller");  /* Print string on 0th page of GLCD */
    while(1);
}

void GLCD_Init()                      /* GLCD Initialization function */
{
    Ctrl_dir = 0;                     /* Make Control pin direction as output */
    Data_dir = 0;                     /* Make Data pin direction as output */
    OSCCON = 0x72;                    /* Internal 8MHz OSC Frequency */
    RST = 1;                          /* Make reset pin High */
	CS1 = 1; CS2 = 1;              	/* Select first Left half of display */
    MSdelay(20);
    GLCD_Command(0x3E);               /* Display OFF */
    GLCD_Command(0x40);               /* Set Y address (column=0) */
    GLCD_Command(0xB8);               /* Set x address (page=0) */
    GLCD_Command(0xC0);               /* Set z address (start line=0) */
    GLCD_Command(0x3F);               /* Display ON */
}

void GLCD_Command(char cmd)           /* GLCD Command function */
{
    LCD_data = cmd;                   /* Copy command on data pin */
    RS = 0;                           /* Make RS LOW to select command register */
    EN = 1;                           /* Make HIGH to LOW transition on Enable pin */
    NOP();
    NOP();
    EN = 0;
    NOP();
    NOP();
}

void GLCD_Char(char data)             /* GLCD Data function */
{
    LCD_data = data;                  /* Copy Data on data pin */
    RS = 1;                           /* Make RS HIGH to select data register */
    EN = 1;                           /* Make HIGH to LOW transition on Enable pin */
    NOP();
    NOP();
    EN = 0;
    NOP();
    NOP();
}

void GLCD_String(char page_no, char *str)           	/* GLCD string write function */
{
	unsigned int i,column,Page=((0xB8)+page_no),Y_address=0;	
	float Page_inc=0.5;													
	CS1 = 1; CS2 = 0;                               	/* Select first Left half of display */
	GLCD_Command(Page);
	for(i=0;str[i]!=0;i++)                          	/* Print each char in string till null */
	{
       if (Y_address>(1024-(((page_no)*128)+5)))        /* Check Whether Total Display get overflowed */
          break;                                        /* If yes then break writing */
        if (str[i]!=32)                                 /* Check whether character is not a SPACE */
        {
            for (column=1;column<=5;column++)
            {
                if ((Y_address+column)==(128*((int)(Page_inc+0.5))))	/* If yes then check whether it overflow from right side of display */
                {
                    if (column==5)                      /* Also check and break if it overflow after 5th column */
                        break;
                    GLCD_Command(0x40);                 /* If not 5th and get overflowed then change Y address to START column */
                    Y_address = Y_address+column;       /* Increment Y address count by column no. */
                    CS1 = ~CS1; CS2 = ~CS2;             /* If yes then change segment controller to display on other half of display */
                    GLCD_Command((Page+Page_inc));      /* Execute command for page change */
                    Page_inc=Page_inc+0.5;              /* Increment Page No. by half */
                }
            }
        }
        if (Y_address>(1024-(((page_no)*128)+5)))       /* Check Whether Total Display get overflowed */
            break;                                      /* If yes then break writing */
        if((font[((str[i]-32)*5)+4])==0 || str[i]==32)  /* Check whether character is SPACE or character last column is zero */
        {
            for(column=0;column<5;column++)
            {
                GLCD_Char(font[str[i]-32][column]); 	/* If yes then then print character */
                if((Y_address+1)%64==0)         		/* check whether it gets overflowed  from either half of side */
                {
                    CS1 = ~CS1; CS2 = ~CS2;             /* If yes then change segment controller to display on other half of display */ 
                    GLCD_Command((Page+Page_inc));  	/* Execute command for page change */
                    Page_inc=Page_inc+0.5;              /* Increment Page No. by half */
                }
                Y_address++;							/* Increment Y_address count per column */
            }
        }
        else											/* If character is not SPACE or character last column is not zero */
        {
            for(column=0;column<5;column++)
            {
                GLCD_Char(font[str[i]-32][column]); 	/* Then continue to print hat char */
                if((Y_address+1)%64==0)					/* check whether it gets overflowed  from either half of side */
                {
                    CS1 = ~CS1; CS2 = ~CS2;				/* If yes then change segment controller to display on other half of display */ 
                    GLCD_Command((Page+Page_inc));		/* Execute command for page change */
                    Page_inc=Page_inc+0.5;				/* Increment Page No. by half */
                }
                Y_address++;							/* Increment Y_address count per column */
            }
            GLCD_Char(0);								/* Add one column of zero to print next character next of zero */
            Y_address++;								/* Increment Y_address count for last added zero */
            if((Y_address)%64==0)						/* check whether it gets overflowed  from either half of side */
            {
                CS1 = ~CS1; CS2 = ~CS2;					/* If yes then change segment controller to display on other half of display */ 
                GLCD_Command((Page+Page_inc));			/* Execute command for page change */
                Page_inc=Page_inc+0.5;					/* Increment Page No. by half */
            }
        }
    }
	GLCD_Command(0x40);									/* Set Y address (column=0) */
}

void GLCD_Clear()
{
	int i,j;
	CS1 = 1; CS2 = 1;									/* Select both left & right half of display */
	for(i=0;i<8;i++)
	{
		GLCD_Command((0xB8)+i);							/* Increment page each time after 64 column */
		for(j=0;j<64;j++)
		{
			GLCD_Char(0);								/* Write zeros to all 64 column */
		}
	}
	GLCD_Command(0x40);									/* Set Y address (column=0) */
	GLCD_Command(0xB8);									/* Set x address (page=0) */
}
/*********************************Delay Function********************************/
void MSdelay(unsigned int val)
{
     unsigned int i,j;
        for(i=0;i<=val;i++)
            for(j=0;j<165;j++);/*This count Provide delay of 1 ms for 8MHz Frequency */
}