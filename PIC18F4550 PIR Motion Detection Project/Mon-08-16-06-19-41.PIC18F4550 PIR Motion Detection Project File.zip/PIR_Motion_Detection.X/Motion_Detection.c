/*
 * PIR Motion sensor interface with PIC18F4550
 * http://www.electronicwings.com
 */


#include <pic18f4550.h>
#include "Configuration_Header_File.h"

#define Motion_detection PORTAbits.RA0      /* Read PIR sensor's data on this pin */
#define PORT_Dir TRISAbits.RA0              /* define for setting direction */
#define LED LATD0                           /* connect LED to the PORTD.0 pin */
#define LED_Dir TRISDbits.RD0               /* define for setting direction */

void MSdelay(unsigned int val);

void main(void) 
{
    ADCON1=0x0F;        /* this makes all pins as a digital I/O pins */    
    PORT_Dir = 1;       /* set as input port */
    LED_Dir = 0;        /* set as output port */
    LED = 0;            /* initially turned OFF LED */
    OSCCON = 0x72;
    while(1)
    {
        while(Motion_detection)        
            LED = 1;     /* LED turn ON if any Human motion is detected */  
        
            LED = 0;     /* LED turn OFF */    
    }
}
void MSdelay(unsigned int val)
{
     unsigned int i,j;
        for(i=0;i<=val;i++)
            for(j=0;j<81;j++);      /*This count Provide delay of 1 ms for 8MHz Frequency */
 }