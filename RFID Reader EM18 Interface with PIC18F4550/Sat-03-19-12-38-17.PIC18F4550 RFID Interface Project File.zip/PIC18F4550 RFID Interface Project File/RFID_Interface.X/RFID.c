/*
 * 125 kHz RFID interface with PIC18F4550
 * http://www.electronicwings.com
 * 
 */


#include <string.h>
#include <stdio.h>
//#include <xc.h>
#include "Configuration_Header_File.h"
#include "LCD_16x2_8-bit_Header_File.h"
#include "USART_Header_File.h"
void main(void) 
{
    unsigned char i;
    unsigned char ID[13];
    OSCCON=0x72;                 /* select internal oscillator freq = 8 Mhz */ 
    LCD_Init();                  /* initialize LCD16x2 */
    USART_Init(9600);            /* initialize USART Communication with 9600 baud rate*/
    memset(ID,0,13);
    LCD_String_xy(0,0,"RFID: ");
    while(1)
    {        
        for(i=0;i<12;i++)
        {   
            ID[i]=USART_RxChar();   // Receiving Data and Storing it in data_in
        }  
        LCD_String_xy(1,0,ID);        // Send Received data to LCD
        memset(ID,0,13);
    }
}
