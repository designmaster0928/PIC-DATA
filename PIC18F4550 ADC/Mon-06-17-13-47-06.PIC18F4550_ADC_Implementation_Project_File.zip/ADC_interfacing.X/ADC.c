#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <P18F4550.h>
#include "config_intosc.h"          /* Header File for Configuration bits */
#include "LCD_8bit_file.h"          /* Header File for LCD Functions */


void ADC_Init();
int ADC_Read(int);


#define vref 5.00               /*Reference Voltage is 5V*/

void main()
{    
    char data[10];    
    int digital;  
    float voltage;
    OSCCON=0x72;                /*Set internal Oscillator frequency to 8 MHz*/
    LCD_Init();                 /*Initialize 16x2 LCD*/
    ADC_Init();                 /*Initialize 10-bit ADC*/
    
    LCD_String_xy(1,1,"Voltage is...");

    while(1)
    {        
        digital = ADC_Read(0);
        voltage = digital*((float)vref/(float)1023);    /*Convert digital value into analog voltage*/
        sprintf(data,"%.2f",voltage);                  /*It is used to convert integer value to ASCII string*/
        strcat(data," V");                             /*Concatenate result and unit to print*/
        LCD_String_xy(2,4,data);                       /*send string data for printing*/   
		MSdelay(500);
    }
    
}

void ADC_Init()
{    
    TRISA = 0xff;       /*set as input port*/
    ADCON1 = 0x0e;      /*ref vtg is VDD and Configure pin as analog pin*/    
    ADCON2 = 0x92;      /*Right Justified, 4Tad and Fosc/32. */
    ADRESH = 0;           /*Flush ADC output Register*/
    ADRESL = 0;   
}

int ADC_Read(int channel)
{
    int digital;
    ADCON0 =(ADCON0 & 0b11000011)|((channel<<2) & 0b00111100);      /*channel 0 is selected i.e (CHS3CHS2CHS1CHS0=0000) 
                                                                      and ADC is disabled i.e ADON=0*/
    ADCON0 |= ((1<<ADON)|(1<<GO));                   /*Enable ADC and start conversion*/
    while(ADCON0bits.GO_nDONE==1);                  /*wait for End of conversion i.e. Go/done'=0 conversion completed*/        
    digital = (ADRESH*256) | (ADRESL);              /*Combine 8-bit LSB and 2-bit MSB*/
    return(digital);
}



