/* 
 Enter PIC18F4550 in sleep and wake-up through external interrupt
 www.electronicwings.com 
*/

#include <pic18f4550.h>
#include "osc_config.h"

void MSdelay(unsigned int);
#define LED LATD

int flag;

void main()
{    
    TRISD=0;
    TRISBbits.RB0=1;        /*set PORTB.0 as input*/
    OSCCON=0x72;            /*configure a oscillator frequency to 8MHz with IDLEN=0,
                            enabling IDLEN enables sleep mode */
    INTCON2=0x00;           /*INT0 negative edge interrupt selected*/	
    INTCONbits.INT0IF=0;    /*clear INT0 interrupt flag*/
    INTCONbits.INT0IE=1;    /*enable INTOIF interrupt*/
    INTCONbits.GIE=1;       /*enable global interrupt*/
    flag = 0;
    LED = 0;               /*turn OFF led initially*/
    while(!flag)
    {
        LED = ~LED;       /*blink LED continuously*/
        MSdelay(300);
    }
    SLEEP();                /*enter in sleep mode*/
}

void interrupt ISR()
{
    flag = ~flag;
    INTCONbits.INT0IF=0;
}

void MSdelay(unsigned int val)
{
 unsigned int i,j;
 for(i=0;i<=val;i++)
     for(j=0;j<81;j++);
 }