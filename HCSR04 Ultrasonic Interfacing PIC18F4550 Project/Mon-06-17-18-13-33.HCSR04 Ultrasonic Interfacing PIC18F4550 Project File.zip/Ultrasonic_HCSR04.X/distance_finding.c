/*
  Interfacing Ultrasonic module HC-SR04 with PIC18F4550 for finding distance to an object
  http://www.electronicwings.com
 */

#include <xc.h>
#include <pic18f4550.h>
#include <stdio.h>
#include "Configuration_Header_File.h"
#include "16x2_LCD_4bit_File.h"

void Trigger_Pulse_10us();

#define _XTAL_FREQ 8000000      /* define macros to use internal __delay_us function */
#define Trigger_Pulse LATD0     /* PORTD.0 pin is connected to Trig pin of HC-SR04 */

void main()
{
    float Distance;
    int Time;
    float Total_distance[10];
    OSCCON=0x72;            /* use internal oscillator with * MHz frequency */
    TRISB = 0xff;           /* define PORTB as Input port*/
    TRISD = 0;              /* define PORTD as Output port*/
    INTCON2bits.RBPU=0;     /*enable PORTB Pull-ups */
    LCD_Init();
    Trigger_Pulse = 0;
    T1CON = 0x80;           /* enable 16-bit TMR1 Register,No pre-scale,
                             * use internal clock,Timer OFF */
    TMR1IF = 0;             /* make Timer1 Overflow Flag to '0' */
    TMR1=0;                 /* load Timer1 with 0 */
    LCD_String_xy(1,1," Distance:");
while(1)
{    
    
    Trigger_Pulse_10us();               /* transmit at least 10 us pulse to HC-SR04 */
    while(PORTBbits.RB0==0);            /* wait for rising edge at Echo pin of HC-SR04 */
    TMR1=0;                             /* Load Timer1 register with 0 */
    TMR1ON=1;                           /* turn ON Timer1*/
    while(PORTBbits.RB0==1 && !TMR1IF); /* wait for falling edge at Echo pin of HC-SR04*/
    Time = TMR1;                        /* copy Time when echo is received from an object */
    TMR1ON=0;                           /* turn OFF Timer1 */
    Distance = ((float)Time/117.00);           /* distance = (velocity x Time)/2 */
    sprintf(Total_distance,"%.03f",Distance);
    LCD_String_xy(2,1,Total_distance);
    LCD_String("  cm");
    MSdelay(50);
}   
}
void Trigger_Pulse_10us()
{
    Trigger_Pulse = 1;
    __delay_us(10);
    Trigger_Pulse = 0;
}

