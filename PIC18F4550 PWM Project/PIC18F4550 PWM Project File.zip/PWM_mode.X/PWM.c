
/*
* Generate 10 KHz PWM with 20% duty cycle
* www.electronicwings.com
*/

#include "config_intosc.h"
#include <pic18f4550.h>


void main()
{

    OSCCON=0x72;         /* set internal clock to 8MHz */
    TRISC2=0;            /* Set CCP1 pin as output for PWM out */
    PR2=199;             /* load period value */ 
    CCPR1L=40;           /* load duty cycle */
    T2CON=0;             /* no pre-scalar,timer2 is off */
    CCP1CON=0x0C;        /* set PWM mode and no decimal value for PWM */                 
    TMR2=0;              /*Clear Timer2 initially */
    TMR2ON=1;            /*timer ON for start counting*/
    while(1);
    
}
