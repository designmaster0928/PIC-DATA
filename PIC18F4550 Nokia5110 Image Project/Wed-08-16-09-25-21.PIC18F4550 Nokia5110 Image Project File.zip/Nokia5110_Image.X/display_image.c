/*
 * Nokia 5110 display interface with PIC18F4550
 * http://www.electronicwings.com
 */

#include <pic18f4550.h>
#include "Configuration_Header_File.h"
#include "SPI_Header_File.h"
#include "Microchip_Image.h"

void Nokia_Init();
void Nokia_SendCommand(char);
void Nokia_SendData(char);
void Nokia_SendString(char *);
void MSdelay(unsigned int);
void Nokia_Clear();
void Nokia_PositionXY(char, char);
void Nokia_DisplayImage(const unsigned char *);
#define DC LATD0      
#define RES LATD1     /* connected to reset */

void main()
{
    OSCCON = 0X72;              /* set internal oscillator frequency, 8 MHz*/
    TRISD = 0;                  /* set PORT as output port*/
    SPI_Init_Master();          /* initialize SPI master*/
    Nokia_Init();               /* initialize Nokia 5110 display */
    Nokia_Clear();              /* clear Nokia display */
    Nokia_PositionXY(0,0);      /* set X and Y position for printing */   
    Nokia_DisplayImage(img);
    while(1);
    
}
void Nokia_SendCommand(char cmd)
{
    DC = 0;         /* Data/Command pin, D/C=1 - Data, D/C = 0 - Command*/
    CS = 0;         /* enable chip */
    SPI_Write(cmd); /* write command to the Nokia 5110 */
    CS = 1;         /* disable chip */
}

void Nokia_PositionXY(char X, char Y)
{
    Nokia_SendCommand(0x80 | X);    /* set X position */
    Nokia_SendCommand(0x40 | Y);    /* set Y position */  
}

void Nokia_Init()
{
    /*apply 100 ms reset(low to high) pulse */
    RES = 0;                    /* enable reset */
    MSdelay(100);
    RES = 1;                    /* disable reset */
    Nokia_SendCommand(0x21);    /* use extended instruction set */
    Nokia_SendCommand(0x13);    /* select Bias voltage */
    Nokia_SendCommand(0x07);    /* set temperature coefficient */
    Nokia_SendCommand(0xC0);    /* set LCD Vop for contrast */    
    Nokia_SendCommand(0x20);    /* use basic instruction set */    
    Nokia_SendCommand(0x0C);    /* set normal mode */
   
}

void Nokia_Clear()
{
    char i,j;
    CS = 0;
    DC = 1;
    for(i=0;i<6;i++)
    {   
        for(j=0;j<84;j++)
            SPI_Write(0);       /*write 0 to clear display */
    }      
    CS = 1;
    
}

void Nokia_DisplayImage(const unsigned char *image)
{
    int i;
    CS = 0;
    DC = 1;
    for(i=0;i<504;i++)        
    {
        SPI_Write(image[i]);        
    }    
    CS = 1;
}

/*********************************Delay Function********************************/
void MSdelay(unsigned int val)
{
     unsigned int i,j;
        for(i=0;i<=val;i++)
            for(j=0;j<81;j++);      /*This count Provide delay of 1 ms for 8MHz Frequency */
 }