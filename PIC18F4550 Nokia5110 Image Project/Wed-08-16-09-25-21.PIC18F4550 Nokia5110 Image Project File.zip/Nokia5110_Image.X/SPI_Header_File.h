
/*
 * PIC18F4550 SPI Header File
 * http://www.electronicwings.com
 */
// This is a guard condition so that contents of this file are not included
// more than once.  
#ifndef SPI_HEADER_H
#define	SPI_HEADER_H

/*
 * Interface SPI based EEPROM 25AA1024 with PIC18F4550
 * http://www.electronicwings.com
 */

#include <pic18f4550.h>

void SPI_Write(unsigned char);
void SPI_Init_Master();
unsigned char SPI_Read();
void SPI_Init_Slave();

#define CS LATA5

#endif	/* SPI_HEADER_H */

