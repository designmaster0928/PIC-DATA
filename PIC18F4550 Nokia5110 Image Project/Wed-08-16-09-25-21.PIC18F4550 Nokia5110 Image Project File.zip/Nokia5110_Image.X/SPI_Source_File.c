/*
 * Interface SPI based EEPROM 25AA1024 with PIC18F4550
 * http://www.electronicwings.com
 */

#include "SPI_Header_File.h"

void SPI_Init_Master()
{
/*PORT definition for SPI pins*/    
    TRISBbits.TRISB0 =1;    /* RB0 as input(SDI) */
    TRISBbits.TRISB1=0;     /* RB1 as output(SCK) */
    TRISAbits.TRISA5=0;     /* RA5 as a output(SS') */
    TRISCbits.TRISC7=0;     /* RC7 as output(SDO) */
/*to initialize SPI Communication configure following Register*/
    CS = 1;
    SSPSTAT=0x40;   /*Data change on rising edge of clk , BF=0*/
    SSPCON1=0x22;   /*master mode,Serial enable, idle state low for clk, fosc/64 */ 
    PIR1bits.SSPIF=0;
/* disable the ADC channel which are on for multiplexed pin when used as an input */    
    ADCON0=0;       /*this is for de-multiplexed the SCL and SDI from analog pins*/
    ADCON1=0x0F;    /*this makes all pins as a digital I/O pins*/    
}

void SPI_Write(unsigned char x)
{
    unsigned char data_flush;
     SSPBUF=x;                   /* put data in SSBUF which has to transmit */

    while(!PIR1bits.SSPIF);      /* wait for complete 1 byte transmission */
    PIR1bits.SSPIF=0;            /* clear SSPIF flag */
    data_flush=SSPBUF;           /* flush the data as simultaneous read occurs */
}

unsigned char SPI_Read()
{    
    SSPBUF=0xff;                 /* Put flush data in SSBUF to read from device */
    while(!PIR1bits.SSPIF);      /* wait for complete 1 byte transmission */
    PIR1bits.SSPIF=0;
    return(SSPBUF);              /* read data as it is returned from slave to master.
                                     so SSPBUF is ready to receive new data.*/   
}

