
#include "osc_config.h"     /* Oscillator configuration header file */
#include <pic18f4550.h>     /* Contain PIC18F4550 specifications */

#define Pulse LATB          /* Define Pulse as LATB to output on PORTB */

void Timer1_delay();

void main()
{
    OSCCON=0x72;        /* Configure oscillator frequency to 8MHz */
    TRISB=0;            /* Set as output Port */
    Pulse=0xff;         /* send high on PortB */
    
    while(1)
    {
        Pulse=~Pulse;   /* Toggle Value at PortB to generate waveform of 500 Hz */ 
        Timer1_delay(); /* Call function which provide desired delay */    
    }   
}


/*************************delay function using Timer1*******************/
void Timer1_delay()
{
    T1CON=0x80;         /* Enable 16-bit TMR1 Register,No pre-scale,use internal clock,Timer OFF */
    TMR1=0xf830;        /* Load Count for generating delay of 1ms */
    T1CONbits.TMR1ON=1; /* Turn-On Timer1 */
    while(PIR1bits.TMR1IF==0);      /* Wait for Timer1 overflow Interrupt flag to set */
    TMR1ON=0;           /* Turn-OFF Timer */
    TMR1IF=0;           /* Make Timer1 Overflow Flag to '0' */                
}

