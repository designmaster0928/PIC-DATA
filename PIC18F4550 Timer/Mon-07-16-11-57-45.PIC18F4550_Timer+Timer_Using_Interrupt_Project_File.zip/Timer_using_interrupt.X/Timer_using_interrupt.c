/*
 * Generate 1ms delay by using PIC18F4550 Timer1 Interrupt Service Routine ISR
 * www.electronicwings.com  
 */
#include <pic18f4550.h>
#include "Configuration_Header_File.h"

void Timer1_start();

#define Pulse LATB

void main()
{ 
    OSCCON=0x72;    /* Configure oscillator frequency to 8MHz */
    TRISB = 0;      /* Set as output Port */
    Pulse = 0xff;   /* send high on PortB */
    Timer1_start();
    
    while(1);
    
}
/*********************Interrupt Service Routine for Timer1************************/
void interrupt Timer1_ISR()
{
    
    TMR1=0xF856;
    Pulse = ~Pulse;    /* Toggle Value at PortB to generate waveform of 500 Hz */   
    PIR1bits.TMR1IF=0; /* Make Timer1 Overflow Flag to '0' */
}

void Timer1_start()
{
    GIE=1;              /* Enable Global Interrupt */
    PEIE=1;             /* Enable Peripheral Interrupt */
    TMR1IE=1;           /* Enable Timer1 Overflow Interrupt */
    TMR1IF=0;
    T1CON=0x80;         /* Enable 16-bit TMR1 Register,No pre-scale,use internal clock,Timer OFF */
    TMR1=0xF856;        /* Load Count for generating delay of 1ms */
    TMR1ON=1;           /* Turn-On Timer1 */
}