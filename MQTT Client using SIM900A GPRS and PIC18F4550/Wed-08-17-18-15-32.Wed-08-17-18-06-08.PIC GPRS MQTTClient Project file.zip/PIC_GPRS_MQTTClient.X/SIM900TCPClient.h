/*
 * SIM900TCPClient.h
 * http://www.electronicwings.com
 */

#ifndef SIM900TCPCLIENT_H			/* Define library H file if not defined */
#define SIM900TCPCLIENT_H

#include <stdint.h>
#include <stdio.h>					/* Include standard library */
#include <stdlib.h>					/* Include standard library */
#include <string.h>					/* Include string library */
#include <stdbool.h>				/* Include standard boolean library */
#include <pic18f4550.h>
#include "USART_Header_File.h"		/* Include USART header file */
#include "Configuration_header_file.h"

#define DEFAULT_BUFFER_SIZE		200
#define DEFAULT_TIMEOUT			10000
#define DEFAULT_CRLF_COUNT		2

enum SIM900_RESPONSE_STATUS {
	SIM900_RESPONSE_WAITING,
	SIM900_RESPONSE_FINISHED,
	SIM900_RESPONSE_TIMEOUT,
	SIM900_RESPONSE_BUFFER_FULL,
	SIM900_RESPONSE_STARTING,
	SIM900_RESPONSE_ERROR
};

char RESPONSE_BUFFER[DEFAULT_BUFFER_SIZE];

void Read_Response();
void TCPClient_Clear();
void Start_Read_Response();
void GetResponseBody(char* Response, uint16_t ResponseLength);
bool WaitForExpectedResponse(const char* ExpectedResponse);
bool SendATandExpectResponse(const char* ATCommand, const char* ExpectedResponse);
bool TCPClient_ApplicationMode(uint8_t Mode);
bool TCPClient_ConnectionMode(uint8_t Mode);
bool AttachGPRS();
bool SIM900_Start();
bool TCPClient_Shut();
bool TCPClient_Close();
bool TCPClient_Connect(const char* _APN, const char* _USERNAME, const char* _PASSWORD);
bool TCPClient_connected();
int16_t TCPClient_DataAvailable();
uint8_t TCPClient_DataRead();
uint8_t TCPClient_Start(uint8_t _ConnectionNumber, char* Domain, char* Port);
uint8_t TCPClient_Send(char* Data, uint16_t _length);
void interrupt ISR();

#endif