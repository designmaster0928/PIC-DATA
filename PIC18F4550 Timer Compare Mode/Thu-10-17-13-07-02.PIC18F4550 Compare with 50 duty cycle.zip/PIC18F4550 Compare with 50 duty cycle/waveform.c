#include "comp_osc.h"
#include <p18f4550.h>

void main()
{
    OSCCON=0x72;                /* Configure internal clock at 8MHz */
    TRISCbits.TRISC1=0;         /* Configure RC2 pin as output */
    CCP2CON=0x02;               /* module is configured for compare mode and 
                                   is set up so that upon a compare match of CCPR1 and TMR3, RC2 is driven low*/         
    PIR2bits.CCP2IF=0;          /* Clear interrupt flag*/
    TMR3=0;                     /* Clear Timer3 Register*/
    T3CON=0xC0;                 /* Timer3 used for compare mode with TMR3 register in 16-bit format*/
    CCPR2=1000;                 /* load a count for generating 1khz*/
    T3CONbits.TMR3ON=1;         /* Turn On Timer3*/   
    while (1)
    {
      while(PIR2bits.CCP2IF==0);/*wait for CCP Interrupt flag to set,
                                  it is set on compare match between CCPR1 and TMR3*/
      PIR2bits.CCP2IF=0;        /*Clear interrupt flag*/
      TMR3=0;           
    }
}
