/*
 * File:   ECHO_Generation.c
 * 
 * www.electronicwings.com
 */

#include <pic18f4550.h>
#include "Configuration_Header_File.h"
#include "LCD_16x2_8-bit_Header_File.h"

void USART_Init(int);
void USART_TxChar(char);
char USART_RxChar();

#define F_CPU 8000000/64

//#define Baud_value(baud_rate) (((float)(F_CPU)/(float)baud_rate)-1)

#define Baud_value (((float)(F_CPU)/(float)baud_rate)-1)

/************************CODE FOR ECHO GENERATION USING UART*****************/
void main()
{
    OSCCON=0x72;    
    char data_in;
    LCD_Init();               /*Initialize 16x2 LCD */
    USART_Init(9600);         /*initialize USART operation with 9600 baud rate*/ 
    MSdelay(50);
    while(1)
    {
        data_in=USART_RxChar();
        LCD_Char(data_in);
        USART_TxChar(data_in);
    }
    
}

/*****************************USART Initialization*******************************/
void USART_Init(long baud_rate)
{
    float temp;
    TRISC6=0;                       /*Make Tx pin as output*/
    TRISC7=1;                       /*Make Rx pin as input*/
    temp=Baud_value;     
    SPBRG=(int)temp;                /*baud rate=9600, SPBRG = (F_CPU /(64*9600))-1*/
    TXSTA=0x20;                     /*Transmit Enable(TX) enable*/ 
    RCSTA=0x90;                     /*Receive Enable(RX) enable and serial port enable */
}
/******************TRANSMIT FUNCTION*****************************************/ 
void USART_TxChar(char out)
{        
        while(TXIF==0);            /*wait for transmit interrupt flag*/
        TXREG=out;                 /*wait for transmit interrupt flag to set which indicates TXREG is ready
                                    for another transmission*/    
}
/*******************RECEIVE FUNCTION*****************************************/
char USART_RxChar()
{

while(RCIF==0);                 /*wait for receive interrupt flag*/
    if(RCSTAbits.OERR)
    {           
        CREN = 0;
        NOP();
        CREN=1;
    }
    return(RCREG);                  /*receive data is stored in RCREG register and return to main program */
}


