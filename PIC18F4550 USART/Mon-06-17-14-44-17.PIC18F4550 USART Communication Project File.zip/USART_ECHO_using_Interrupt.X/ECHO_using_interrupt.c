/*
 * File:   ECHO_using_interrupt.c
 * 
 * www.electronicwings.com
 */

#include <pic18f4550.h>
#include "Configuration_Header_File.h"
#include "LCD_16x2_8-bit_Header_File.h"

void USART_Init(int);

#define F_CPU 8000000/64

char out;

void main()
{
    OSCCON=0x72;
    MSdelay(10);
    LCD_Init();
    USART_Init(9600);    
    LCD_String_xy(1,0,"Receive");
    LCD_Command(0xC0);
    while(1);
}

void interrupt ISR()
{
      while(RCIF==0);
        out=RCREG;               /*received data copy from RCREG register*/
      LCD_Char(out);
      while(TXIF==0);
        TXREG=out;               /*received data is transmitted(ECHO) via TXREG register*/
    
}

void USART_Init(int baud_rate)
{   
    float temp;
    TRISC6=0;           /*Make Tx pin as output*/
    TRISC7=1;           /*Make Rx pin as input*/
    temp=(((float)(F_CPU)/(float)baud_rate)-1);     
    SPBRG=(int)temp;    /*baud rate=9600 SPBRG=(F_CPU /(64*9600))-1*/
    TXSTA=0x20;         /*TX enable; */
    RCSTA=0x90;         /*RX enanle and serial port enable*/
    INTCONbits.GIE=1;   /*Enable Global Interrupt */
    INTCONbits.PEIE=1;  /*Enable Peripheral Interrupt */
    PIE1bits.RCIE=1;    /*Enable Receive Interrupt*/
    PIE1bits.TXIE=1;    /*Enable Transmit Interrupt*/
}