/*
 * File:   Receive_Char.c
 * 
 * www.electronicwings.com
 */

#include <pic18f4550.h>
#include "Configuration_Header_File.h"
#include "LCD_16x2_8-bit_Header_File.h"

void USART_Init(int);
char USART_ReceiveChar();

#define F_CPU 8000000/64

//#define Baud_value(baud_rate) (((float)(F_CPU)/(float)baud_rate)-1)

#define Baud_value (((float)(F_CPU)/(float)baud_rate)-1)

void main()
{
    char data_in;
    OSCCON=0x72;                /*set internal oscillator freq=8 Mhz*/ 
   
    LCD_Init();                 /*Initialize 16x2 LCD */
    USART_Init(9600);           /*initialize USART operation with 9600 baud rate*/
    LCD_String_xy(1,0,"SERIAL RECEIVE");/*Display String SERIAL RECEIVE at 1st Row and 1st starting location*/
    LCD_Command(0xc0);          /*Display Received character at 2nd row 1st location*/
     
    while(1)
    {       
       data_in=USART_ReceiveChar(); 
       LCD_Char(data_in);
    }
    
    
}


/*****************************USART Initialization*******************************/
void USART_Init(long baud_rate)
{
    float temp;
    TRISC6=0;                       /*Make Tx pin as output*/
    TRISC7=1;                       /*Make Rx pin as input*/
    temp=Baud_value;     
    SPBRG=(int)temp;                /*baud rate=9600, SPBRG = (F_CPU /(64*9600))-1*/
    RCSTA=0x90;                     /*Receive Enable(RX) enable and serial port enable */
}
//*******************RECEIVE FUNCTION*****************************************//
char USART_ReceiveChar()
{

    while(RCIF==0);                 /*wait for receive interrupt flag*/
    if(RCSTAbits.OERR)
    {           
        CREN = 0;
        NOP();
        CREN=1;
    }
    return(RCREG);                  /*received in RCREG register and return to main program */
}

